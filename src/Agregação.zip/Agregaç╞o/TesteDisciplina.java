package Agregação;

public class TesteDisciplina {
    public static void main(String[] args) {
    Professor a = new Professor();
    Disciplina b = new Disciplina("Matematica");
    a.imprimir();
    b.imprimirNomeDisciplina();
    }
}
